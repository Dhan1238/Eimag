  import { initializeApp} from "https://www.gstatic.com/firebasejs/9.20.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.20.0/firebase-analytics.js";
  import { getAuth, signInWithEmailAndPassword,signOut,setPersistence,onAuthStateChanged, createUserWithEmailAndPassword,updateProfile} from "https://www.gstatic.com/firebasejs/9.20.0/firebase-auth.js";
  import { getDatabase, ref, set,update } from "https://www.gstatic.com/firebasejs/9.20.0/firebase-database.js";


 const firebaseConfig = {
  apiKey: "AIzaSyAvDx01_m0RtvMk32t20ur-kPVjnR097oQ",

  authDomain: "login-for-ctf.firebaseapp.com",

  databaseURL: "https://login-for-ctf-default-rtdb.firebaseio.com",

  projectId: "login-for-ctf",

  storageBucket: "login-for-ctf.appspot.com",

  messagingSenderId: "171849821279",

  appId: "1:171849821279:web:91571d1850c4098101ffea"

  };

  
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
  const Auth = getAuth();
  const database = getDatabase(app);
  var dName="";
 
 

  var name = document.getElementById("Name");
  var mal = document.getElementById("mail");
  var pass = document.getElementById("password");
 
  onAuthStateChanged(Auth,(user)=>{
    if(user){
      console.log("logged in");
    }
    else{
      console.log("logged out");
      //document.getElementById('aurl').href="#";
    }
  })

  window.login = function login(e){
    e.preventDefault();
    var obj = {
        mal: mal.value,
        pass: pass.value,
    }
    const dt = new Date();
    signInWithEmailAndPassword(Auth,obj.mal,obj.pass)
    .then(function(success){
        const user = Auth.currentUser;
        if (user !== null) {
            user.providerData.forEach((profile) => {
             dName = profile.displayName;
           });
           update(ref(database,'Users/'+user.uid),{
            Last_Login: dt
           })
        }
        sessionStorage.setItem("UserName",dName);
     
        window.location.href = "index.html";
    })
    .catch(function(err){
      if(err =="FirebaseError: Firebase: Error (auth/wrong-password)." || err=="FirebaseError: Firebase: Error (auth/user-not-found)."){
        swal("Error","Incorrect Username or Password","error");
      }
       
    })
  };

  window.logout = function logout(e){
    signOut(Auth)
    .then(function(success){
      sessionStorage.removeItem("UserName");
      window.location.href="index.html";
      
    })
    .catch(function(error){
      swal("Error","Something went wrong","error");
    })
  };

  window.Info = function Info(e){
    onAuthStateChanged(Auth,(user)=>{
      if(user){
        document.getElementById('disname').textContent = user.displayName;
        document.getElementById('email').textContent = user.email;
      }
      else{
   
      }
    })
      
  };

  window.signup = function(e){
    e.preventDefault();
    var obj = {
       name:name.value,
       mal:mal.value,
       pass:pass.value,
    };
    var username = "";
     //Generating username
     let x = Math.floor((Math.random() * 10) + 1);
     username += obj.name+ obj.mal.length + x;
     
     const dt = new Date();
     createUserWithEmailAndPassword(Auth,obj.mal,obj.pass)
     .then((userCredential) => {
        
        // Signed in 
        const user = userCredential.user; // this gets the current user who has logged in
        updateProfile(user,{
          displayName: name.value, // we are updating their name
       });
       
        set(ref(database,'Users/'+ user.uid),{
           Name:obj.name,
           Email:obj.mal,
           Completed:0,
           Score:0,
           UserName:username,
           Last_Login: dt
        }).then(function(success){
          alert("Registered Successfully");
          sessionStorage.setItem("UserName",name.value);
          window.location.href = "index.html";
        })
        .catch(function(error){
           alert(error);
        })      
      })
    
  .catch(function(err){
    if(err=="FirebaseError: Firebase: Error (auth/email-already-in-use)."){
   swal("Error","User already exits","error");
    }
  });
     
 };