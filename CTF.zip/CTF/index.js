//url encoding
function u11(){
   let a = document.getElementById('uq11').value;
   let b = a.toUpperCase();
   if(b==="HELLO WORLD"){
    alert("You captured a flag");
    document.getElementById('uq11').value = "";
   }
   else{
      alert("Try Again!");
      document.getElementById('uq11').value = "";
   }
}

function u12(){
   let a = document.getElementById('uq12').value;
   
   if(a==="What's your name?"){
    alert("You captured a flag");
    document.getElementById('uq12').value = "";
   }
   else{
      alert("Try Again!");
      document.getElementById('uq12').value = "";
   }
}
function u13(){
   let a = document.getElementById('uq13').value;
  
   if(a==="This & That"){
    alert("You captured a flag");
    document.getElementById('uq13').value = "";
   }
   else{
      alert("Try Again!");
      document.getElementById('uq13').value = "";
   }
}
function u14(){
   let a = document.getElementById('uq14').value;
   
   if(a==="Café"){
    alert("You captured a flag");
    document.getElementById('uq14').value = "";
   }
   else{
      alert("Try Again!");
      document.getElementById('uq14').value = "";
   }
}
function u15(){
   let a = document.getElementById('uq15').value;
   if(a==="https://example.com/page?param=value"){
    alert("You captured a flag");
    document.getElementById('uq15').value = "";
   }
   else{
      alert("Try Again!");
      document.getElementById('uq15').value = "";
   }
}